package com.burger.fiksens

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.provider.Settings

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 12, 12)
    private val panel = Color.rgb(27, 27, 27)
    private val red = Color.rgb(229, 57, 53)
    private lateinit var status: TextView
    private lateinit var dpiValue: TextView
    private lateinit var dpi: SeekBar
    private val prefs by lazy { getSharedPreferences("profiles", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 26, 22, 20)
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        content.addView(label("ФИКС СЕНСЫ ОТ БУРГЕРА", 25, red, true))
        content.addView(label("Бесплатные игровые профили • Android 8+", 13, Color.LTGRAY))
        content.addView(cardSpace())

        status = label("Проверка Root и Shizuku доступна в диагностике ниже", 14, Color.WHITE)
        content.addView(section("ДОСТУП"))
        content.addView(status)
        val check = button("Проверить Root")
        check.setOnClickListener { checkRoot() }
        content.addView(check)
        val shizuku = button("Проверить Shizuku")
        shizuku.setOnClickListener {
            status.text = "Shizuku: для интеграции нужен установленный Shizuku и выданное приложению разрешение. В этой стартовой версии системные команды не запускаются."
        }
        content.addView(shizuku)

        content.addView(section("ПРОФИЛЬ ЧУВСТВИТЕЛЬНОСТИ"))
        content.addView(label("Чувствительность (локальная рекомендация)", 14, Color.WHITE))
        val sens = SeekBar(this).apply { max = 200; progress = prefs.getInt("sens", 100) }
        val sensValue = label("Значение: ${sens.progress}", 14, Color.LTGRAY)
        sens.setOnSeekBarChangeListener(listener { v -> sensValue.text = "Значение: $v"; prefs.edit().putInt("sens", v).apply() })
        content.addView(sens); content.addView(sensValue)

        content.addView(label("DPI / плотность — только подсказка, не изменяется автоматически", 14, Color.WHITE))
        dpi = SeekBar(this).apply { max = 500; progress = prefs.getInt("dpi", 160) - 80 }
        dpiValue = label("Целевое значение: ${dpi.progress + 80} DPI", 14, Color.LTGRAY)
        dpi.setOnSeekBarChangeListener(listener { v -> dpiValue.text = "Целевое значение: ${v + 80} DPI"; prefs.edit().putInt("dpi", v + 80).apply() })
        content.addView(dpi); content.addView(dpiValue)

        content.addView(section("ПРОФИЛИ"))
        content.addView(button("Сохранить профиль") {
            prefs.edit().putInt("sens", sens.progress).putInt("dpi", dpi.progress + 80).apply()
            Toast.makeText(this, "Профиль сохранён на устройстве", Toast.LENGTH_SHORT).show()
        })
        content.addView(button("Сбросить профиль") {
            sens.progress = 100; dpi.progress = 80
            prefs.edit().putInt("sens", 100).putInt("dpi", 160).apply()
            Toast.makeText(this, "Значения сброшены", Toast.LENGTH_SHORT).show()
        })
        content.addView(section("ВАЖНО"))
        content.addView(label("Пока приложение только хранит рекомендованные значения. Оно не меняет файлы Standoff 2, не вмешивается в игру и не запускает команды Root. Перед добавлением Root/Shizuku-команд будут предусмотрены подтверждение, резервная копия и восстановление исходных настроек.", 13, Color.LTGRAY))
        page.addView(scroll)
        setContentView(page)
    }

    private fun checkRoot() {
        Thread {
            val result = try {
                val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
                val output = p.inputStream.bufferedReader().readText()
                val code = p.waitFor()
                code == 0 && output.contains("uid=0")
            } catch (_: Exception) { false }
            runOnUiThread {
                status.text = if (result) "Root: доступ подтверждён" else "Root: не обнаружен или разрешение не выдано"
            }
        }.start()
    }

    private fun listener(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) onChange(p) }
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
    }

    private fun section(t: String) = label(t, 13, red, true).apply { setPadding(0, 24, 0, 8) }
    private fun label(t: String, size: Int, color: Int, bold: Boolean = false) =
        TextView(this).apply { text = t; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(null, 1); setPadding(0, 5, 0, 5) }
    private fun cardSpace(): View = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, 12) }
    private fun button(t: String, action: (() -> Unit)? = null) = Button(this).apply {
        text = t; setTextColor(Color.WHITE); setBackgroundColor(red)
        setOnClickListener { action?.invoke() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 }
    }
}
